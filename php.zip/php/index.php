<?php 
  include "menu.php";
  include "functions.php";
  
  echo "Daftar menu\n";
  echo "=======================\n";
  for ($i = 0; $i < count($menus); $i++) {
    echo "{$menus[$i]['foodId']} - {$menus[$i]['foodName']} (Rp {$menus[$i]['price']})\n";
  }
  echo "=======================\n";
  echo "Pilih menu yang ingin dibeli dan ketik 'selesai' jika ingin menyelesaikan pemesanan\n\n";

  $total = 0;

  function getOrderCount($inputMenu, &$total) {
    global $menus;

    echo "Jumlah yang dibeli: ";
    $inputOrderCount = (int)trim(fgets((STDIN)));
    echo "\n";

    if (!checkStock($inputMenu, $inputOrderCount)) {
      $index = array_search($inputMenu, array_column($menus, 'foodId'));
      echo "Stok tidak mencukupi!, Jumlah stok saat ini: {$menus[$index]['stock']}\n";
      getOrderCount($inputMenu, $total);
    } else {
      $index = array_search($inputMenu, array_column($menus, 'foodId'));
      $total += calculateTotalPrice($menus[$index]['price'], $inputOrderCount);
      return;
    }
  }

  function getInput(&$total) {
    echo "Pilih menu: ";
    $inputMenu = strtoupper(trim(fgets(STDIN)));
    echo "\n";

    if ($inputMenu != "SELESAI") {
      getOrderCount($inputMenu, $total);
    }
    
    if ($inputMenu != "SELESAI") {
      getInput($total);
    } else {
      echo "\n==========================\n";
      echo "Jumlah yang harus dibayar: Rp {$total}\n";
    }
  }

  getInput($total);
?>