<?php 
  include "menu.php";

  function calculateTotalPrice($price, $quantity) {
    return $price * $quantity;
  }

  function checkStock($foodId, $quantity) {
    global $menus;

    $index = array_search($foodId, array_column($menus, 'foodId'));
    if ($quantity <= $menus[$index]['stock']) {
      return true;
    } else {
      return false;
    }

  }
?>