<?php 
  $menus = [
    [
      'foodId' => 'F001',
      'foodName' => 'Nasi Goreng',
      'price' => 15000,
      'stock' => 50
    ],
    [
      'foodId' => 'F002',
      'foodName' => 'Mie Ayam',
      'price' => 12000,
      'stock' => 50
    ],
    [
      'foodId' => 'F003',
      'foodName' => 'Sosis Bakar',
      'price' => 8000,
      'stock' => 50
    ],
  ];
?>